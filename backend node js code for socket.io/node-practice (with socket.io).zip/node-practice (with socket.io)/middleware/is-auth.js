const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
    const authHeader = req.get('Authorization');
    if (!authHeader) {
        const error = new Error('Not authenticated.');
        error.statusCode = 401;
        throw error;
    }
    const token = authHeader.split(' ')[1];
    let decodeToken;
    try {
        // verify will accept the two arguments one is token and another is the same secret key which we passed at the time of generating token.
        decodeToken = jwt.verify(token, 'secretkey'); // verify will decode the token and also verify if the token is valid or not.
    } catch (error) {
        error.statusCode = 500;
        throw error;
    }
    if (!decodeToken) {
        const error = new Error('Not authenticated.');
        error.statusCode = 401;
        throw error;
    }
    req.userId = decodeToken.userId;
    next();
};